package com.mypoe_varsitycollege.imad5112_project

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class stats : AppCompatActivity() {

    private lateinit var btnclear : Button
    private lateinit var btnaverage : Button
    private lateinit var btnminandmax : Button
    private lateinit var number : EditText
    private lateinit var display1 : TextView
    private lateinit var display2 : TextView

    private val numbers = mutableListOf<Int>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_stats)

        btnclear = findViewById(R.id.btnclear)
        btnaverage = findViewById(R.id.btnaverage)
        btnminandmax = findViewById(R.id.btnminandmax)
        number = findViewById(R.id.number)
        display1 = findViewById(R.id.display1)
        display2 = findViewById(R.id.display2)

        btnaverage.setOnClickListener {
            calculateAverage()
        }

        btnminandmax.setOnClickListener {
            findMinAndMax()
        }

        btnclear.setOnClickListener {
            clearDisplay()
        }
    }

    private fun clearDisplay() {
        display1.text = ""
        display2.text = ""
        numbers.clear()
    }

    private fun calculateAverage() {
        if (numbers.isEmpty()) {
            display2.text = "No numbers entered!"
            return
        }

        val sum = numbers.sum()
        val average = sum.toDouble() / numbers.size
        display2.text = "Average: $average"
    }

    private fun findMinAndMax() {
        if (numbers.isEmpty()) {
            display2.text = "No numbers entered!"
            return
        }

        val min = numbers.minOrNull()
        val max = numbers.maxOrNull()

        display2.text = "Min: $min, Max: $max"
    }

    // Function to handle adding numbers to display1
    fun addNumber() {
        val numText = number.text.toString()
        if (numText.isNotEmpty()) {
            val num = numText.toInt()
            if (numbers.size < 10) {
                numbers.add(num)
                display1.append("$num ")
                number.text.clear()
            } else {
                display2.text = "Maximum of 10 numbers reached!"
            }
        }
    }
}
